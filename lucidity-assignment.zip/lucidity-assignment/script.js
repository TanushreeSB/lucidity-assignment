document.getElementsByClassName(Product) {
    setTimeout({
        console.log("Edit Product")
    }, 3000);
};

document.querySelector("button");

document.getElementsByClassName(Actions){
    Edit.addEventListener(){
        alert("Are you sure you want to delete the product?")
    }
}

